/*
 * Step_Motor.c
 *
 *  Created on: Jul 6, 2021
 *      Author: kccistc
 */
#include "main.h"

void Step_Motor()
{
	      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 1); //  A
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0); //  B
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0); // /A
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0); // /B
		  HAL_Delay(1);
		  // 1 0x01

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);
	  	  HAL_Delay(1);
	  	  // 2 0x03

	      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 0);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 1);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);
		  HAL_Delay(1);
		  // 3 0x02

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 0);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 1);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 1);
		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);
		  HAL_Delay(1);
		  //4 0x06

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);
	  	  HAL_Delay(1);
	  	  // 5 0x04

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 1);
	  	  HAL_Delay(1);
	  	  // 6 0x0c

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 1);
	  	  HAL_Delay(1);
	  	  // 7 0x08

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 1);
	  	  HAL_Delay(1);
	  	  // 8  0x09

		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, 1);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, 0);
	  	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);
	  	  HAL_Delay(1);
	  	  // 9 0x01
}
